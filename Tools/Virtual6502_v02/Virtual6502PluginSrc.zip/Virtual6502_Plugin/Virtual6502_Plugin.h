// Virtual6502_Plugin.h : main header file for the Virtual6502_Plugin DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CVirtual6502_PluginApp
// See Virtual6502_Plugin.cpp for the implementation of this class
//

class CVirtual6502_PluginApp : public CWinApp
{
public:
	CVirtual6502_PluginApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
