// Virtual6502_Plugin.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "Virtual6502_Plugin.h"
#include "Shared6502.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//
//TODO: If this DLL is dynamically linked against the MFC DLLs,
//		any functions exported from this DLL which call into
//		MFC must have the AFX_MANAGE_STATE macro added at the
//		very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//


// CVirtual6502_PluginApp

BEGIN_MESSAGE_MAP(CVirtual6502_PluginApp, CWinApp)
END_MESSAGE_MAP()


// CVirtual6502_PluginApp construction

CVirtual6502_PluginApp::CVirtual6502_PluginApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CVirtual6502_PluginApp object

CVirtual6502_PluginApp theApp;


// CVirtual6502_PluginApp initialization

BOOL CVirtual6502_PluginApp::InitInstance()
{
	CWinApp::InitInstance();

	return TRUE;
}

CPluginAPI *g_api;

//called every tick from the emulator.
//if cpuActive is false, the debugger is halted or the cpu has been reset.
void Plugin_TickFunction(emuContext_t *context, BYTE *bank, bool cpuActive)
{
	//do logic here for checking registers, rendering, etc.
}

//do premature cleanup
void Plugin_Shutdown(void)
{
	//if there's any to do.
}

//get/give api functions pointers
void Plugin_ExchangeAPI(CPluginAPI *ptr)
{
	g_api = ptr;
	g_api->Plugin_TickFunction = Plugin_TickFunction;
	g_api->Plugin_Shutdown = Plugin_Shutdown;
	g_api->Plugin_OpCodeHandler = NULL;
}
